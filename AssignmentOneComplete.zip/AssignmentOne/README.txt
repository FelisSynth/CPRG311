How to run this program
Created by - Joshua Law, Dylano Van Der Meer, Felix Tran, Dominik Bureckert

Sorting methods
s - Selection Sort
b - Bubble Sort
i - Insertion Sort
m - Merge Sort
q - Quick Sort
z - Heap Sort

Sorting parameters
h - Height
v - Volume
a - Area



Step 1 - Open up CMD from the start menu
Step 2 - Locate the directory in which you have sort.jar located
Step 3 - Run the command java -jar sort.jar -f[File location] -s[sorting method] -t[sort parameter]
Example. java -jar sort.jar -fpolyfor1.txt -Tv -Sb
Step 4 - Click enter
Step 5 - Sit back and enjoy