package ca.sait.problemdomain;

/**
 * @author OS
 * TriangularPrism shape class
 */
public class TriangularPrism extends Shape {
	/**
	 * height of triangular prism
	 */
	private double height;
	/**
	 * edge length of triangular prism
	 */
	private double edgeLength;

	/**
	 * Constructor to make TriangularPrism shapes
	 * @param height
	 * @param edgeLength
	 */
	public TriangularPrism(double height, double edgeLength) {
		this.height = height;
		this.edgeLength = edgeLength;
		this.setHeight(this.height);
		this.setBaseArea((this.edgeLength * this.edgeLength * Math.sqrt(3)) / 4);
		this.setVolume(getBaseArea() * this.height);
	}
}