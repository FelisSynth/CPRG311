package ca.sait.problemdomain;

import java.io.*;
import java.util.*;
import java.lang.reflect.*;

import ca.sait.exception.*;
import ca.sait.utilities.*;

/**
 * @author OS
 * Driver class that holds the Main method and the program's processes
 */
public class Driver {
	
	/**
	 * Main method that takes in command line input as a String to invoke methods based on user's needs
	 * Main method uses reflection to call methods based on the command line input
	 * @param <T>
	 * @param args
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws FileNotFoundException
	 * @throws WrongCommandLineInput 
	 * @throws FileNotFound 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static <T extends Comparable<T>> void main(String [] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, FileNotFoundException, WrongCommandLineInput, FileNotFound {
        String sortingMethod = "";
        String sortParameter = "";
        String filePath = "";
        
        for(String input : args) {
        	if(input.toLowerCase().startsWith("-f")) {
        		filePath = input.substring(2);
        	} else if(input.toLowerCase().startsWith("-t")) {
        		sortParameter = input.substring(2);
        	} else if(input.toLowerCase().startsWith("-s")) {
        		sortingMethod = input.substring(2);
        	}
        }
        
        Comparator vc = new VolumeComparator();
        Comparator bc = new BaseAreaComparator();
        Scanner reader;
        try
        {
        	reader = new Scanner(new File(filePath));
        }
        catch(FileNotFoundException e)
        {
        	throw new FileNotFound("\n\nFile location is improper \nplease check to make sure \nits in the correct location and try again");
        }
        
        System.out.println("Loading . . . ");
        
        int size = reader.nextInt();
        Shape[] shapeArray = new Shape[size - 1];
        
        for(int x = 0; x < size - 1; x++) {

            String name = reader.next();
            Double first = reader.nextDouble();
            Double second = reader.nextDouble();

            Class<?> myClass = Class.forName("ca.sait.problemdomain." + name);
            Constructor<?> myConstructor = myClass.getConstructor(double.class,double.class);
            shapeArray[x] = (Shape) myConstructor.newInstance(first, second);
        }
        
        Long startTime = System.currentTimeMillis();
			switch(sortingMethod) {
        case "s":
        	switch(sortParameter) {
        	case "h":
        		SelectionSort.sort(shapeArray);
        		break;
        	case "v":
        		SelectionSort.sort(shapeArray, vc);
        		break;
        	case "a":
        		SelectionSort.sort(shapeArray, bc);
        		break;
        	}
        	break;
        	
        case "b":
        	switch(sortParameter) {
        	case "h":
        		BubbleSort.sort(shapeArray);
        		break;
        	case "v":
        		BubbleSort.sort(shapeArray, vc);
        		break;
        	case "a":
        		BubbleSort.sort(shapeArray, bc);
        		break;
        	}
        	break;
        	
        case "i":
        	switch(sortParameter) {
        	case "h":
        		InsertionSort.sort(shapeArray);
        		break;
        	case "v":
        		InsertionSort.sort(shapeArray, vc);
        		break;
        	case "a":
        		InsertionSort.sort(shapeArray, bc);
        		break;
        	}
        	break;
        	
        case "m":
        	switch(sortParameter) {
        	case "h":
        		MergeSort.sort(shapeArray);
        		break;
        	case "v":
        		MergeSort.sort(shapeArray, vc);
        		break;
        	case "a":
        		MergeSort.sort(shapeArray, bc);
        		break;
        	}
        	break;
        	
        case "q":
        	switch(sortParameter) {
        	case "h":
        		QuickSort.sort(shapeArray);
        		break;
        	case "v":
        		QuickSort.sort(shapeArray, vc);
        		break;
        	case "a":
        		QuickSort.sort(shapeArray, bc);
        		break;
        	}
        	break;
        	
        case "z":
        	switch(sortParameter) {
        	case "h":
        		HeapSort.sort(shapeArray);
        		break;
        	case "v":
        		HeapSort.sort(shapeArray, vc);
        		break;
        	case "a":
        		HeapSort.sort(shapeArray, bc);
        		break;
        	}
        default:
    		throw new WrongCommandLineInput("\n\nYour command line input is wrong \nplease follow the following example for refrence \n-f[file location] -t[sort parameter] -s[sorting method] \njava -jar sort.jar -fpolyfor1.txt -Tv -Sb");
		}
        
        
        System.out.println("Time to complete sort: " + (System.currentTimeMillis()-startTime) + "ms");
        System.out.println("Greatest: " + shapeArray[0]);
        System.out.println("Smallest: " + shapeArray[size - 2]);
        for(int x = 1000; x < size; x += 1000) {
        	System.out.println("The " + x + "th shape: " + shapeArray[x]);
        }
        reader.close();

	}
}