package ca.sait.problemdomain;

/**
 * @author OS
 * OctagonalPrism shape class
 */
public class OctagonalPrism extends Shape {
	/**
	 * Height of OctagonalPrism
	 */
	private double height;
	/**
	 * Edge length of OctagonalPrism base
	 */
	private double edgeLength;

	/**
	 * Constructor to create OctagonalPrism shape
	 * @param height
	 * @param edgeLength
	 */
	public OctagonalPrism(double height, double edgeLength) {
		this.height = height;
		this.edgeLength = edgeLength;
		this.setHeight(this.height);
		this.setBaseArea(2 * (1 + Math.sqrt(2)) * this.edgeLength * this.edgeLength);
		this.setVolume(getBaseArea() * this.height);
	}
}
