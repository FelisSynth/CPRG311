package ca.sait.problemdomain;

import java.util.Comparator;

/**
 * @author OS
 * Class to compare base area of 2 shapes
 */
public class BaseAreaComparator implements Comparator<Shape> {

	/**
	 * compare method that takes 2 shapes and compare their area
	 */
	@Override
	public int compare(Shape shape1, Shape shape2) {
		if (shape1.getBaseArea() > shape2.getBaseArea()) {
			return 1;
		}
		return -1;
	}

}