package ca.sait.problemdomain;

/**
 * @author OS
 * Pyramid shape class
 */
public class Pyramid extends Shape {
	/**
	 * height of Pyramid shape
	 */
	private double height;
	/**
	 * edge length of Pyramid shape base
	 */
	private double edgeLength;

	/**
	 * Constructor to make Pyramid shapes
	 * @param height
	 * @param edgeLength
	 */
	public Pyramid(double height, double edgeLength) {
		this.height = height;
		this.edgeLength = edgeLength;
		this.setHeight(this.height);
		this.setBaseArea(this.edgeLength * this.edgeLength);
		this.setVolume((getBaseArea() * this.height)/3);
	}
}