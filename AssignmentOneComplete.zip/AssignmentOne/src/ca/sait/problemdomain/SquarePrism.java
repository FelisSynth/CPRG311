package ca.sait.problemdomain;

/**
 * @author OS
 * SquarePrism shape class
 */
public class SquarePrism extends Shape {
	/**
	 * height of square prism
	 */
	private double height;
	/**
	 * edge length of square prism
	 */
	private double edgeLength;

	/**
	 * Constructor to make SquarePrism shapes
	 * @param height
	 * @param edgeLength
	 */
	public SquarePrism(double height, double edgeLength) {
		this.height = height;
		this.edgeLength = edgeLength;
		this.setHeight(this.height);
		this.setBaseArea(this.edgeLength * this.edgeLength);
		this.setVolume(this.getBaseArea() * this.height);
	}
}
