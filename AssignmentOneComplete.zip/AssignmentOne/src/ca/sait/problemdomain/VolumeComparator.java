package ca.sait.problemdomain;

import java.util.Comparator;

/**
 * @author OS
 * Class to compare volume of 2 shapes
 */
public class VolumeComparator implements Comparator<Shape> {

	/**
	 * compare method that takes 2 shapes and compare their volume
	 */
	@Override
	public int compare(Shape shape1, Shape shape2) {
		if (shape1.getVolume() > shape2.getVolume()) {
			return 1;
		}
		return -1;
	}

}