package ca.sait.problemdomain;

/**
 * @author OS
 * Abstract class that is the superclass of all shapes used
 */
abstract class Shape implements Comparable<Shape> {
	/**
	 * height, volume and base area which are the common traits of all shapes
	 */
	private double height;
	private double volume;
	private double baseArea;

	/**
	 * @return shape's height
	 */
	public double getHeight() {
		return height;
	}

	/**
	 * @param height shape's height
	 */
	public void setHeight(double height) {
		this.height = height;
	}

	/** 
	 * @return shape's volume
	 */
	public double getVolume() {
		return volume;
	}

	/**
	 * @param volume shape's volume
	 */
	public void setVolume(double volume) {
		this.volume = volume;
	}

	/**
	 * @return shape's base area
	 */
	public double getBaseArea() {
		return baseArea;
	}

	/**
	 * @param baseArea shape's base area
	 */
	public void setBaseArea(double baseArea) {
		this.baseArea = baseArea;
	}

	/**
	 * method to compare two shape's height
	 */
	@Override
	public int compareTo(Shape shape) {
		if (this.getHeight() > shape.getHeight()) {
			return 1;
		} else if (this.getHeight() < shape.getHeight()) {
			return -1;
		}
		return 0;

	}

	/**
	 * Method to display results in a formatted String
	 */
	public String toString() {
		return(this.getClass().getSimpleName() + " | Height: " + this.height + "| BaseArea: " + this.getBaseArea() + "| Volume: " + this.getVolume());
	}
	
	

}