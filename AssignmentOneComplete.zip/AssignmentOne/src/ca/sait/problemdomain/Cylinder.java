package ca.sait.problemdomain;

/**
 * @author OS
 * Cylinder shape class
 */
public class Cylinder extends Shape {
	/**
	 * Height of Cylinder
	 */
	private double height;
	/**
	 * Radius of Cylinder base or top
	 */
	private double radius;

	/**
	 * Constructor to make Cylinder shape
	 * @param height
	 * @param radius
	 */
	public Cylinder(double height, double radius) {
		this.height = height;
		this.radius = radius;
		this.setHeight(this.height);
		this.setBaseArea(this.radius * this.radius * Math.PI);
		this.setVolume(getBaseArea() * getHeight());
	}
}