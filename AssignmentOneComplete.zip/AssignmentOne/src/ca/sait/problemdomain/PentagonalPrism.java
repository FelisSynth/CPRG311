package ca.sait.problemdomain;

/**
 * @author OS
 * PentagonalPrism shape class
 */
public class PentagonalPrism extends Shape {
	/**
	 * height of PentagonalPrism
	 */
	private double height;
	/**
	 * Edge length of PentagonalPrism base
	 */
	private double edgeLength;

	/**
	 * Constructor to make PentagonalPrism shapes
	 * @param height
	 * @param edgeLength
	 */
	public PentagonalPrism(double height, double edgeLength) {
		this.height = height;
		this.edgeLength = edgeLength;
		this.setHeight(this.height);
		this.setBaseArea((this.edgeLength * this.edgeLength * 5 * (Math.tan(54))) / 4);
		this.setVolume(getBaseArea() * this.height);
	}
}
