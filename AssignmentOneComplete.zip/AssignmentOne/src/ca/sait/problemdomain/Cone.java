package ca.sait.problemdomain;

/**
 * @author OS
 * Cone shape class
 */
public class Cone extends Shape {
	/**
	 * Height of Cone
	 */
	private double height;
	/**
	 * Radius of Cone base
	 */
	private double radius;

	/**
	 * Constructor to make a Cone shape
	 * @param height
	 * @param radius
	 */
	public Cone(double height, double radius) {
		this.height = height;
		this.radius = radius;
		this.setHeight(this.height);
		this.setBaseArea(this.radius * this.radius * Math.PI);
		this.setVolume((getBaseArea() * getHeight()) / 2);
	}
}