package ca.sait.utilities;

import java.util.*;

/**
 * @author OS
 * the class for merge sort method
 * sort in descending order
 */
public class MergeSort implements SortStrategy {
	/**
	 * merge portion of the sort method for compareTo() method
	 * @param <T>
	 * @param array array of any type
	 * @param l left value
	 * @param m middle value
	 * @param r right value
	 */
	@SuppressWarnings("unchecked")
	static <T extends Comparable<T>> void mergeArray(T[] array, int l, int m, int r) {
		int n1 = m - l + 1;
		int n2 = r - m;

		T[] L = (T[]) new Comparable[n1];
		T[] R = (T[]) new Comparable[n2];

		for (int i = 0; i < n1; ++i)
			L[i] = array[l + i];
		for (int j = 0; j < n2; ++j)
			R[j] = array[m + 1 + j];

		int i = 0, j = 0;

		int k = l;
		while (i < n1 && j < n2) {
			if (((Comparable<T>) L[i]).compareTo(R[j]) > 0) {
				array[k] = L[i];
				i++;
			} else {
				array[k] = R[j];
				j++;
			}
			k++;
		}

		while (i < n1) {
			array[k] = L[i];
			i++;
			k++;
		}

		while (j < n2) {
			array[k] = R[j];
			j++;
			k++;
		}
	}

	/**
	 * method to split the arrays in half until there only exists arrays of length 1
	 * for sorting method using compareTo()
	 * @param <T>
	 * @param array array of any type
	 * @param l left value
	 * @param r right value
	 */
	static <T extends Comparable<T>> void sortArray(T[] array, int l, int r) {
		if (l < r) {
			int m = l + (r - l) / 2;

			sortArray(array, l, m);
			sortArray(array, m + 1, r);

			mergeArray(array, l, m, r);
		}
	}
	
	/**
	 * sort method using compareTo()
	 * calls the sortArray() and mergeArray() methods
	 * @param <T>
	 * @param array array of any type
	 */
	public static <T extends Comparable<T>> void sort(T[] array) {
		int l = 0;
		int r = array.length - 1;
		int m = l + (r - l) / 2;

		sortArray(array, l, m);
		sortArray(array, m + 1, r);

		mergeArray(array, l, m, r);
	}
	

	/**
	 * merge portion of the sort method for compare() method
	 * @param <T>
	 * @param array array of any type
	 * @param l left value
	 * @param m middle value
	 * @param r right value
	 * @param c Comparator object
	 */
	@SuppressWarnings("unchecked")
	static <T extends Comparable<T>> void mergeArrayC(T[] array, int l, int m, int r, Comparator<T> c) {
		int n1 = m - l + 1;
		int n2 = r - m;

		T[] LL = (T[]) new Comparable[n1];
		T[] RR = (T[]) new Comparable[n2];

		for (int i = 0; i < n1; ++i)
			LL[i] = array[l + i];
		for (int j = 0; j < n2; ++j)
			RR[j] = array[m + 1 + j];

		int i = 0, j = 0;

		int k = l;
		while (i < n1 && j < n2) {
			if (c.compare(LL[i], RR[j]) > 0) {
				array[k] = LL[i];
				i++;
			} else {
				array[k] = RR[j];
				j++;
			}
			k++;
		}

		while (i < n1) {
			array[k] = LL[i];
			i++;
			k++;
		}

		while (j < n2) {
			array[k] = RR[j];
			j++;
			k++;
		}
	}

	/**
	 * method to split the arrays in half until there only exists arrays of length 1
	 * for sorting method using compare() method
	 * @param <T>
	 * @param array array of any type
	 * @param l left value
	 * @param r right value
	 * @param c Comparator object
	 */
	static <T extends Comparable<T>> void sortArrayC(T[] array, int l, int r, Comparator<T> c) {
		if (l < r) {
			int m = l + (r - l) / 2;

			sortArrayC(array, l, m, c);
			sortArrayC(array, m + 1, r, c);

			mergeArrayC(array, l, m, r, c);
		}
	}

	
	/**
	 * sort method for compare() method
	 * calls the sortArrayC() and mergeArrayC() methods
	 * @param <T>
	 * @param array array of any type
	 * @param c Comparator object
	 */
	public static <T extends Comparable<T>> void sort(T[] array, Comparator<T> c) {
		int l = 0;
		int r = array.length - 1;
		int m = l + (r - l) / 2;

		sortArrayC(array, l, m, c);
		sortArrayC(array, m + 1, r, c);

		mergeArrayC(array, l, m, r, c);
	}
}