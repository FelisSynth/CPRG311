package ca.sait.utilities;

import java.util.*;

/**
 * @author OS
 * the class for selection sort method
 * sort in descending order
 */
public class SelectionSort implements SortStrategy {
	/**
	 * sort method for compareTo() method
	 * @param <T>
	 * @param array of any type
	 */
	public static <T extends Comparable<T>> void sort(T[] array) {
		for (int i = 0; i < array.length - 1; i++) {
			int index = i;
			for (int j = i + 1; j < array.length; j++) {
				if (array[j].compareTo(array[index]) > 0) {
					index = j;
				}
			}
			T biggestValue = array[index];
			array[index] = array[i];
			array[i] = biggestValue;
		}
		;
	}

	/**
	 * sort method for compare() method
	 * @param <T>
	 * @param array of any type
	 * @param c Comparator object
	 */
	public static <T> void sort(T[] array, Comparator<? super T> c) {
		for (int i = 0; i < array.length - 1; i++) {
			int index = i;
			for (int j = i + 1; j < array.length; j++) {
				if (c.compare(array[j], array[index]) > 0) {
					index = j;
				}
			}
			T biggestValue = array[index];
			array[index] = array[i];
			array[i] = biggestValue;
		}
		;
	}
}