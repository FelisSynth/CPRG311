package ca.sait.utilities;

/**
 * @author OS
 * Interface for all sort methods
 */
public interface SortStrategy {
	/**
	 * mutual sort method for all sorting strategies
	 * @param <T>
	 * @param array array of any type
	 */
	public static <T extends Comparable<T>> void sort(T[] array) {}
}
