package ca.sait.utilities;
import java.util.*;

/**
 * @author OS
 * the class for heap sort method
 * sort in descending order
 */
public class HeapSort implements SortStrategy {
	/**
	 * heapify method using compareTo() method
	 * @param <T>
	 * @param array array of any type
	 * @param n
	 * @param index
	 */
	public static <T extends Comparable<T>> void heapify(T[] array, int n, int index) {
		int biggest = index;
		int left = 2 * index + 1;
		int right = 2 * index + 2;
		
		if(left<n && array[left].compareTo(array[biggest]) < 0) {
			biggest = left;
		}
		
		if(right<n && array[right].compareTo(array[biggest]) < 0) {
			biggest = right;
		}
		
		if(biggest != index) {
			T temp = array[index];
			array[index] = array[biggest];
			array[biggest] = temp;
			heapify(array, n, biggest);
		}
		
		
	}
	
	
	/**
	 * sorting method for compareTo() method
	 * @param <T>
	 * @param array array of any type
	 */
	public static <T extends Comparable<T>> void sort(T[] array) {
		int n = array.length;
			
			for(int i = n/2-1; i>=0; i--) {
				heapify(array, n, i);
			}
			
			for(int i = n - 1; i>=0; i--) {
				T temp = array[0];
				array[0] = array[i];
				array[i] = temp;
				
				heapify(array, i, 0);
			}
			
		}
	
	/**
	 * heapify method using compare() method
	 * @param <T>
	 * @param array array of any type
	 * @param n
	 * @param index
	 * @param c Comparator object
	 */
	public static <T extends Comparable<T>> void heapifyC(T[] array, int n, int index, Comparator<T> c) {
		int biggest = index;
		int left = 2 * index + 1;
		int right = 2 * index + 2;
		
		if(left<n && c.compare(array[left], array[biggest]) < 0)
		{
			biggest = left;
		}
		
		if(right<n && c.compare(array[right], array[biggest]) < 0) {
			biggest = right;
		}
		
		if(biggest != index) {
			T temp = array[index];
			array[index] = array[biggest];
			array[biggest] = temp;
			heapifyC(array, n, biggest, c);
		}
		
		
	}
	
	/**
	 * sorting method for compare() method
	 * @param <T>
	 * @param array array of any type
	 * @param c Comparator object
	 */
	public static <T extends Comparable<T>> void sort(T[] array, Comparator <T> c) {
		int n = array.length;
			
			for(int i = n/2-1; i>=0; i--) {
				heapifyC(array, n, i, c);
			}
			
			for(int i = n - 1; i>0; i--) {
				T temp = array[0];
				array[0] = array[i];
				array[i] = temp;
				
				heapifyC(array, i, 0, c);
			}
			
		}
}