package ca.sait.utilities;

import java.util.*;

/**
 * @author OS
 * the class for quick sort method
 * sort in descending order
 */
public class QuickSort implements SortStrategy {
	/**
	 * Method to swap 2 array entities
	 * @param <T>
	 * @param array array of any type
	 * @param i
	 * @param j
	 */
	static <T extends Comparable<T>> void swap(T[] array, int i, int j) {
		T temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}

	/**
	 * partitioning method to compare and swap array entities
	 * for compareTo() method
	 * @param <T>
	 * @param array array of any type
	 * @param low low value
	 * @param high high value
	 * @return index
	 */
	static <T extends Comparable<T>> int partition(T[] array, int low, int high) {
		T pivot = array[high];

		int i = (low - 1);

		for (int j = low; j <= high - 1; j++) {

			if (array[j].compareTo(pivot) > 0) {

				i++;
				swap(array, i, j);
			}
		}
		swap(array, i + 1, high);
		return (i + 1);
	}

	/**
	 * Method to recursively partition arrays
	 * for compareTo() method,
	 * invoke partition() and quickSort() method
	 * @param <T>
	 * @param array array of any type
	 * @param low low value
	 * @param high high value
	 */
	static <T extends Comparable<T>> void quickSort(T[] array, int low, int high) {
		if (low < high) {

			int pi = partition(array, low, high);

			quickSort(array, low, pi - 1);
			quickSort(array, pi + 1, high);
		}
	}

	/**
	 * sort method for compareTo() method,
	 * create low and high values
	 * @param <T>
	 * @param array array of any type
	 */
	public static <T extends Comparable<T>> void sort(T[] array) {
		int low = 0;
		int high = array.length - 1;
		quickSort(array, low, high);
	}

	/**
	 * partitioning method to compare and swap array entities
	 * for compare() method
	 * @param <T>
	 * @param array array of any type
	 * @param low low value
	 * @param high high value
	 * @return index
	 */
	static <T extends Comparable<T>> int partitionC(T[] array, int low, int high, Comparator<T> c) {
		T pivot = array[high];

		int i = (low - 1);

		for (int j = low; j <= high - 1; j++) {

			if (c.compare(array[j], pivot) > 0) {

				i++;
				swap(array, i, j);
			}
		}
		swap(array, i + 1, high);
		return (i + 1);
	}

	/**
	 * Method to recursively partition arrays
	 * for compare() method,
	 * invoke partitionC() and quickSortC() method
	 * @param <T>
	 * @param array array of any type
	 * @param low low value
	 * @param high high value
	 */
	static <T extends Comparable<T>> void quickSortC(T[] array, int low, int high, Comparator<T> c) {
		if (low < high) {

			int pi = partitionC(array, low, high, c);

			quickSortC(array, low, pi - 1, c);
			quickSortC(array, pi + 1, high, c);
		}
	}

	/**
	 * sort method for compare() method,
	 * create low and high values
	 * @param <T>
	 * @param array array of any type
	 */
	public static <T extends Comparable<T>> void sort(T[] array, Comparator<T> c) {
		int low = 0;
		int high = array.length - 1;
		quickSortC(array, low, high, c);
	}
}