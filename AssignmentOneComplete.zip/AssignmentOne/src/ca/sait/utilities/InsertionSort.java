package ca.sait.utilities;

import java.util.*;

/**
 * @author OS
 * the class for insertion sort method
 * sort in descending order
 */
public class InsertionSort implements SortStrategy {
	/**
	 * sort method for compareTo() method
	 * @param <T>
	 * @param array of any type
	 */
	public static <T extends Comparable<T>> void sort(T[] array) {
		int n = array.length;
		for (int i = 1; i < n; i++) {
			T key = array[i];
			int j = i - 1;
			while (j >= 0 && array[j].compareTo(key) < 0) {
				array[j + 1] = array[j];
				j = j - 1;
			}
			array[j + 1] = key;
		}
	}

	/**
	 * sort method for compare() method
	 * @param <T>
	 * @param array of any type
	 * @param c Comparator object
	 */
	public static <T extends Comparable<T>> void sort(T[] array, Comparator<T> c) {
		int n = array.length;
		for (int i = 1; i < n; i++) {
			T key = array[i];
			int j = i - 1;
			while (j >= 0 && c.compare(array[j], key) < 0) {
				array[j + 1] = array[j];
				j = j - 1;
			}
			array[j + 1] = key;
		}
	}
}