package ca.sait.exception;

@SuppressWarnings("serial")
public class FileNotFound extends Exception{
	public FileNotFound(String message)
	{
		super(message);
	}

	
}
