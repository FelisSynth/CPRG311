package ca.sait.exception;

@SuppressWarnings("serial")
public class WrongCommandLineInput extends Exception{
	public WrongCommandLineInput(String message)
	{
		super(message);
	}
}
