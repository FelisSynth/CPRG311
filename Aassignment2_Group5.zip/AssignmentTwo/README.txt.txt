Fully Functioning Object Classes for Group 5,
However we were unable to complete a working XML parser so it was removed,
Project is 85-90% done according to marking rubric!