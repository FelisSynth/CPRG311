package utilities;

import java.util.NoSuchElementException;

import exceptions.EmptyQueueException;


public class MyQueue<E> implements QueueADT<E>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	MyDLL<E> myDll = new MyDLL<E>();
	
	@Override
	public void enqueue(E toAdd) throws NullPointerException {
		myDll.add(toAdd);
		
	}

	@Override
	public E dequeue() throws EmptyQueueException {
		return myDll.remove(0);
	}

	@Override
	public E peek() throws EmptyQueueException {
		E temp = myDll.get(0);
		return temp;
	}

	@Override
	public void dequeueAll() {
		myDll.clear();
		
	}

	@Override
	public boolean isEmpty() {
		boolean temp = myDll.isEmpty();
		return temp;
	}

	@Override
	public Iterator<E> iterator() {
		Iterator<E> it = new Iterator<E>() {
			private int currentIndex = 0; 
			
			@Override
			public boolean hasNext() {
				return(currentIndex < size());
			}
			
			@Override
			public E next() throws NoSuchElementException {
				E toReturn = myDll.get(currentIndex);
				currentIndex++;
				return toReturn;
			}
		};
		return it;
	}

	@Override
	public boolean equals(QueueADT<E> that) {
			boolean toReturn = true;
			Iterator<E> it = this.iterator();
			while(it.hasNext()) {
				try {
					if (this.dequeue() != that.dequeue()) {
						return false;
					}
				} catch (EmptyQueueException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return toReturn;
		}
	

	@Override
	public Object[] toArray() {
		Object[] toHold = new Object[size()];
		for(int count = 0; count < size(); count ++) {
			toHold[count] = myDll.get(count);
		}
		return toHold;
	}

	@Override
	public E[] toArray(E[] holder) throws NullPointerException {
		int index = 0;
		Iterator<E> it = this.iterator();
		while(it.hasNext()) {
			holder[index] = it.next();
			index ++;
		}
		return holder;
	}

	@Override
	public boolean isFull() {
		return false;
	}

	@Override
	public int size() {
		return myDll.size();
	}

}
