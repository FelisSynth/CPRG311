package utilities;

import java.util.NoSuchElementException;

public class MyDLL<E> implements ListADT<E> {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8482271807440808220L;
	private Node<E> head = null;
	private Node<E> tail = null;
	private int size = 0;
		
	@Override
	public int size() {
		return size;
	}

	@Override
	public void clear() {
		size = 0;
		head = null;
		tail = null;
	}

	@Override
	public boolean add(int index, E toAdd) throws NullPointerException, IndexOutOfBoundsException {
		Node<E> newNode = new Node<E>(null,null,toAdd);
		if(index == 0) {
			head.previous = newNode;
			newNode.next = head;
			head = newNode;
			size++;
			return true;
		} else {
			Node<E> currentNode = head;
			for(int count = 1; count < index; count ++) {
				currentNode = currentNode.next;
			}
			newNode.next = currentNode.next;
			currentNode.next = newNode;
			newNode.previous = currentNode;
			newNode.next.previous = newNode;
			size++;
			return true;
		}
		
	}

	@Override
	public boolean add(E toAdd) throws NullPointerException {
		Node<E> newNode = new Node<E>(null,null,toAdd);
		if(head == null) {
			size ++;
			head = newNode;
			tail = newNode;
			return true;			
		} else if(size == 1) {
			size ++;
			tail = newNode;
			tail.previous = head;
			head.next = tail;
			return true;
		} else {
			size ++;
			tail.next = newNode;
			newNode.previous = tail;
			tail = newNode;
			return true;
		}
	}

	@Override
	public boolean addAll(ListADT<? extends E> toAdd) throws NullPointerException {
		if(size == 0) {
			head.data = toAdd.get(0);
			size ++;
			return true;
		} else {
			for(int count = 0; count < toAdd.size(); count++) {
				add(toAdd.get(count));
			}
			return true;
			
		}
		
	}

	@Override
	public E get(int index) throws IndexOutOfBoundsException {
		if(index == 0) {
			return head.data;
		} else if(index == size - 1) {
			return tail.data;
		} else {
			Node<E> currentNode = head;
			for(int count = 1; count <= index; count ++) {
				currentNode = currentNode.next;
			}
			return currentNode.data;

		}
	}

	@Override
	public E remove(int index) throws IndexOutOfBoundsException {
		E toReturn;
		if(index == 0) {
			toReturn = head.data;
			head = head.next;
			size --;
			return toReturn;
		} else if(index == size - 1) {
			toReturn = tail.data;
			tail = tail.previous;
			tail.next = null;
			size --;
			return toReturn;
		} else {
			Node<E> currentNode = head;
			for(int count = 1; count <= index; count ++) {
				currentNode = currentNode.next;
			}
			toReturn = currentNode.data;
			currentNode.next.previous = currentNode.previous;
			currentNode.previous.next = currentNode.next;
			size --;
			return toReturn;
		}
	}

	@Override
	public E remove(E toRemove) throws NullPointerException {
		int index = 0;
		if(head.data == toRemove) {
			size--;
			return head.data;
		} else {
			Node<E> currentNode = head;
			while(iterator().hasNext()) {	
				index ++;
				currentNode = currentNode.next;
				if(currentNode.data == toRemove) {
					return remove(index);
				}
			}
		}
		return null;

	}

	@Override
	public E set(int index, E toChange) throws NullPointerException, IndexOutOfBoundsException {
		E toReturn;
		if(index == 0) {
			toReturn = head.data;
			head.data = toChange;
			return toReturn;
		} else if(index == size - 1) {
			toReturn = tail.data;
			tail.data = toChange;
			return toReturn;
		} else {
			Node<E> currentNode = head;
			for(int count = 1; count <= index; count ++) {
				currentNode = currentNode.next;
			}
			toReturn = currentNode.data;
			currentNode.data = toChange;
			return toReturn;
		}
	}
	
	@Override
	public boolean isEmpty() {
		return (size == 0);
	}

	@Override
	public boolean contains(E toFind) throws NullPointerException {
		Node<E>currentNode = head;
		for(int count = 1; count < size(); count ++) {
			if(currentNode.data == toFind) {
				return true;
			}
			currentNode = currentNode.next;
		}
		return false;
	}

	@Override
	public E[] toArray(E[] toHold) throws NullPointerException {
		for(int count = 0; count < size(); count ++) {
			toHold[count] = get(count);
		}
		return toHold;
	}

	@Override
	public Object[] toArray() {
		Object[] toHold = new Object[size()];
		for(int count = 0; count < size(); count ++) {
			toHold[count] = get(count);
		}
		return toHold;
	}

	@Override
	public Iterator<E> iterator() {
			Iterator<E> it = new Iterator<E>() {
			private int currentIndex = 0; 
			
			@Override
			public boolean hasNext() {
				return(currentIndex < size());
			}
			
			@Override
			public E next() throws NoSuchElementException {
				E toReturn = get(currentIndex);
				currentIndex++;
				return toReturn;
			}
		};
		return it;
		
	}
}

class Node<E> {
	Node<E> next;
	Node<E> previous;
	E data;
	
	Node(Node<E> nextNode,Node<E> previousNode, E data) {
		this.next = nextNode;
		this.previous = previousNode;
		this.data = data;
	}
}

