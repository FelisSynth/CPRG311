/**
 * 
 */
package utilities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * @author Dylan
 *
 */
class MyDLLTest {
	MyDLL<String> list = new MyDLL<String>();
	
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		list.add("a");
		list.add("b");
		list.add("c");
		list.add("d");
		list.add("e");	
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
		list.clear();
	}

	/**
	 * Test method for {@link utilities.MyDLL#size()}.
	 */
	@Test
	void testSize() {
		assertTrue(list.size() == 5);
	}

	/**
	 * Test method for {@link utilities.MyDLL#clear()}.
	 */
	@Test
	void testClear() {
		list.clear();
		assertTrue(list.size() == 0);
	}

	/**
	 * Test method for {@link utilities.MyDLL#add(int, java.lang.Object)}.
	 */
	@Test
	void testAddIntObject() {
		list.add(4, "dd");
		assertEquals("dd", list.get(4));

	}

	/**
	 * Test method for {@link utilities.MyDLL#add(java.lang.Object)}.
	 */
	@Test
	void testAddElement() {
		list.add("f");
		assertEquals("a", list.get(0));
		assertEquals("b", list.get(1));
		assertEquals("c", list.get(2));
		assertEquals("d", list.get(3));
		assertEquals("e", list.get(4));
		assertEquals("f", list.get(5));

	}

	/**
	 * Test method for {@link utilities.MyDLL#addAll(utilities.ListADT)}.
	 */
	@Test
	void testAddAll() {
		MyDLL<String> list2 = new MyDLL<String>();
		list2.add("f");
		list2.add("g");
		list2.add("h");
		list2.add("i");
		list2.add("j");
		
		list.addAll(list2);
		assertEquals("f", list.get(5));
		assertEquals("g", list.get(6));
		assertEquals("h", list.get(7));
		assertEquals("i", list.get(8));
		assertEquals("j", list.get(9));

	}

	/**
	 * Test method for {@link utilities.MyDLL#get(int)}.
	 */
	@Test
	void testGet() {
		assertTrue(list.get(2).equals("c"));
	}

	/**
	 * Test method for {@link utilities.MyDLL#remove(int)}.
	 */
	@Test
	void testRemoveInt() {
		list.remove(3);
		assertTrue(list.size() == 4);
		assertEquals("a", list.get(0));
		assertEquals("b", list.get(1));
		assertEquals("c", list.get(2));
		assertEquals("e", list.get(3));
	}

	/**
	 * Test method for {@link utilities.MyDLL#remove(java.lang.Object)}.
	 */
	@Test
	void testRemoveObject() {
		list.remove("d");
		assertEquals(4, list.size());
		assertEquals("a", list.get(0));
		assertEquals("b", list.get(1));
		assertEquals("c", list.get(2));
		assertEquals("e", list.get(3));

	}

	/**
	 * Test method for {@link utilities.MyDLL#set(int, java.lang.Object)}.
	 */
	@Test
	void testSet() {
		list.set(0, "b");
		list.set(1, "a");
		assertEquals("b", list.get(0));
		assertEquals("a", list.get(1));
		assertEquals("c", list.get(2));
		assertEquals("d", list.get(3));
		assertEquals("e", list.get(4));		
	}

	/**
	 * Test method for {@link utilities.MyDLL#isEmpty()}.
	 */
	@Test
	void testIsEmpty() {
		list.clear();
		assertTrue(list.isEmpty());
	}

	/**
	 * Test method for {@link utilities.MyDLL#contains(java.lang.Object)}.
	 */
	@Test
	void testContains() {
		assertFalse(list.contains("z"));
		assertTrue(list.contains("d"));
	}

	/**
	 * Test method for {@link utilities.MyDLL#toArray(java.lang.Object[])}.
	 */
	@Test
	void testToArrayObjectArray() {
		Object[] array = list.toArray();
		assertEquals(array.length, list.size());
		assertEquals(array[0], list.get(0));
		assertEquals(array[1], list.get(1));
		assertEquals(array[2], list.get(2));
		assertEquals(array[3], list.get(3));
		assertEquals(array[4], list.get(4));
	}

	/**
	 * Test method for {@link utilities.MyDLL#toArray()}.
	 * @param <E>
	 */
	@Test
	void testToArray() {
		String[] array = new String[list.size()]; 
		array = list.toArray(array);
		assertEquals(array.length, list.size());
		assertEquals(array[0], list.get(0));
		assertEquals(array[1], list.get(1));
		assertEquals(array[2], list.get(2));
		assertEquals(array[3], list.get(3));
		assertEquals(array[4], list.get(4));
	}

	/**
	 * Test method for {@link utilities.MyDLL#iterator()}.
	 */
	@Test
	void testIterator() {
		Iterator<String> it = list.iterator();
		int count = 0;
		while(it.hasNext()) {
			assertEquals(list.get(count), it.next());
			count++;
		}
	}

}
