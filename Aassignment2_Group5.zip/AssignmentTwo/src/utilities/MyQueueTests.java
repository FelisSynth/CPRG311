package utilities;

import static org.junit.jupiter.api.Assertions.*;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import exceptions.EmptyQueueException;

public class MyQueueTests {

	MyQueue<String> queue = new MyQueue<String>();
	
	@BeforeEach
	void setUp() throws Exception {
		queue = new MyQueue<>();
		queue.enqueue("a");
		queue.enqueue("b");
		queue.enqueue("c");
		queue.enqueue("d");
		queue.enqueue("e");
		queue.enqueue("f");
		queue.enqueue("g");
		queue.enqueue("h");
		queue.enqueue("i");
		queue.enqueue("j");
	}
	
	@AfterEach
	void tearDown() throws Exception {
		queue.dequeueAll();
		queue = null;
	}
	
	@Test
	void testEnqueue() throws EmptyQueueException {
		queue.dequeueAll();
		queue.enqueue("aa");
		assertEquals("aa", queue.peek());
	}
	
	@Test
	void testDequeue() throws EmptyQueueException {
		queue.dequeue();
		assertEquals("b", queue.peek());
	}
	
	@Test
	void testPeek() throws EmptyQueueException {
		assertEquals("a", queue.peek());
	}
	
	@Test
	void testDequeueAll() {
		queue.dequeueAll();
		assertEquals(0, queue.size());
	}
	@Test
	void testIsEmpty() {
		queue.dequeueAll();
		assertTrue(queue.isEmpty());
		assertEquals(queue.size(), 0);
	}
	
	@Test
	void testEquals() {
		MyQueue<String> queue2 = new MyQueue<>();
		queue2.enqueue("a");
		queue2.enqueue("b");
		queue2.enqueue("c");
		queue2.enqueue("d");
		queue2.enqueue("e");
		queue2.enqueue("f");
		queue2.enqueue("g");
		queue2.enqueue("h");
		queue2.enqueue("i");
		queue2.enqueue("j");
		
		assertTrue(queue.equals(queue2));
	}
	
	@Test
	void testToArray() throws EmptyQueueException {
		Object[] array = new Object[queue.size()];
		array = queue.toArray();
		assertEquals(array[0], queue.peek());
	}
	
	@Test
	void testToArrayHold() throws EmptyQueueException {
		String[] array = new String[100];
		queue.toArray(array);
		assertEquals(array[0], queue.peek());
	}
	
	@Test
	void testIsFull() {
		assertTrue(!queue.isFull());
	}
	
	@Test
	void testSize() {
		assertEquals(10, queue.size());
	}
	
	@Test
	void testIterator() throws EmptyQueueException {
		Iterator<String> it = (Iterator<String>) queue.iterator();
		while(it.hasNext()) {
			assertEquals(it.next(), queue.dequeue());
			it = queue.iterator();
		}
	}
}
