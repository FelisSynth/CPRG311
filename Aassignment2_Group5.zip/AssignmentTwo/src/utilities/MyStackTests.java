package utilities;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MyStackTests<E> {
	MyStack<String> stack;
	
	@BeforeEach
	void setUp() throws Exception {
		stack = new MyStack<>();
		stack.push("j");
		stack.push("i");
		stack.push("h");
		stack.push("g");
		stack.push("f");
		stack.push("e");
		stack.push("d");
		stack.push("c");
		stack.push("b");
		stack.push("a");
	}
	
	@AfterEach
	void tearDown() throws Exception {
		stack.clear();
		stack = null;
	}
	
	@Test
	void testSize() {
		assertEquals(10,stack.size());
	}
	
	@Test
	void testClear() {
		stack.clear();
		assertEquals(0, stack.size());
	}
	
	@Test
	void testPush() {
		stack.push("aa");
		assertEquals(11, stack.size());
		assertEquals("aa", stack.peek());
	}
	
	@Test
	void testPop() {
		assertTrue(stack.pop() == "a");
		assertEquals(9, stack.size());
	}
	
	@Test
	void testPeek() {
		assertEquals(stack.peek(), "a");
	}
	
	@Test
	void testIsEmpty() {
		stack.clear();
		assertTrue(stack.isEmpty());
	}
	
	@Test
	void testToArray() {
		Object[] array = new Object[stack.size()];
		array = stack.toArray();
		assertEquals(array[array.length-1], stack.peek());
	}
	
	@Test
	void testToArrayE() {
		String[] array = new String[stack.size()];
		stack.toArray(array);
		assertEquals(array[array.length-1], stack.peek());
	}
	
	@Test
	void testContains() {
		assertTrue(stack.contains("a"));
	}
	
	@Test
	void testSearch() {
		assertEquals(8, stack.search("c"));
	}
	
	@Test
	void testIterator() {
		String toCheck = null;
		for(int count = 1; count < stack.size(); count ++) {
			Iterator<String> it = stack.iterator();
			while(it.hasNext()) 
			{
				toCheck = it.next();
			}
		assertEquals(stack.pop(), toCheck);
		}
	}
	
	@Test
	void testEquals() {
		MyStack<String> stack2 = new MyStack<>();
		stack2.push("j");
		stack2.push("i");
		stack2.push("h");
		stack2.push("g");
		stack2.push("f");
		stack2.push("e");
		stack2.push("d");
		stack2.push("c");
		stack2.push("b");
		stack2.push("a");
		assertTrue(stack.equals(stack2));
	}
	
}
