package utilities;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * @author Dylan
 * @param <E>
 * @param <E>
 *
 */
class MyArrayListTest<E> {
	ListADT<String> list;
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		list = new MyArrayList<>();
		list.add("a");
		list.add("b");
		list.add("c");
		list.add("d");
		list.add("e");
		list.add("f");
		list.add("g");
		list.add("h");
		list.add("i");
		list.add("j");

	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
		list.clear();
		list = null;
	}

	/**
	 * Test method for {@link utilities.MyArrayList#size()}.
	 */
	@Test
	void testSize() {
		assertEquals(10,list.size());
	}

	/**
	 * Test method for {@link utilities.MyArrayList#clear()}.
	 */
	@Test
	void testClear() {
		list.clear();
		assertTrue(list.get(0) == null);
		assertEquals(0,list.size());
	}

	/**
	 * Test method for {@link utilities.MyArrayList#add(int, java.lang.Object)}.
	 */
	@Test
	void testAddIntE() {
		list.add(4, "dd");
		assertEquals("a", list.get(0));
		assertEquals("b", list.get(1)); 
		assertEquals("c", list.get(2));
		assertEquals("d", list.get(3));
		assertEquals("dd", list.get(4));
		assertEquals("e", list.get(5));
		assertEquals("f", list.get(6));
		assertEquals("g", list.get(7));
		assertEquals("h", list.get(8));
		assertEquals("i", list.get(9));
		assertEquals("j", list.get(10));
	}

	/**
	 * Test method for {@link utilities.MyArrayList#add(java.lang.Object)}.
	 */
	@Test
	void testAddE() {
		list.add("h");
		assertEquals("h", list.get(10));
		assertEquals(11, list.size());
	}

	/**
	 * Test method for {@link utilities.MyArrayList#addAll(utilities.ListADT)}.
	 */
	@Test
	void testAddAll() {
		MyArrayList<String> list2 = new MyArrayList<String>();
		list2.add("k");
		list2.add("l");
		list2.add("m");
		list2.add("n");
		list2.add("o");
		
		list.addAll(list2);
		assertEquals("k", list.get(10));
		assertEquals("l", list.get(11));
		assertEquals("m", list.get(12));
		assertEquals("n", list.get(13));
		assertEquals("o", list.get(14));
	}

	/**
	 * Test method for {@link utilities.MyArrayList#get(int)}.
	 */
	@Test
	void testGet() {
		assertTrue(list.get(0) == "a");
	}

	/**
	 * Test method for {@link utilities.MyArrayList#remove(int)}.
	 */
	@Test
	void testRemoveInt() {
		list.remove(0);
		assertEquals("b",list.get(0));
		list.remove(1);
		assertEquals("d", list.get(1));
		assertEquals("j", list.get(7));
		assertEquals(8, list.size());
		
	}

	/**
	 * Test method for {@link utilities.MyArrayList#remove(java.lang.Object)}.
	 */
	@Test
	void testRemoveE() {
		list.remove("a");
		assertEquals("b", list.get(0));
		assertEquals("j", list.get(8));
		assertEquals(9, list.size());
	}

	/**
	 * Test method for {@link utilities.MyArrayList#set(int, java.lang.Object)}.
	 */
	@Test
	void testSet() {
		list.set(0, "aa");
		assertEquals("aa",list.get(0));
	}

	/**
	 * Test method for {@link utilities.MyArrayList#isEmpty()}.
	 */
	@Test
	void testIsEmpty() {
		list.clear();
		assertTrue(list.isEmpty());
	}

	/**
	 * Test method for {@link utilities.MyArrayList#contains(java.lang.Object)}.
	 */
	@Test
	void testContains() {
		list.add("This is a test");
		assertTrue(list.contains("This is a test"));
		assertFalse(list.contains("Ooga Booga"));
	}

	/**
	 * Test method for {@link utilities.MyArrayList#toArray(E[])}.
	 * @param <E>
	 * @param <E>
	 */
	@Test
	void testToArrayEArray() {
		String[] toHold = new String[999];
		list.toArray(toHold);
		assertEquals(toHold[3], list.get(3));
	}

	/**
	 * Test method for {@link utilities.MyArrayList#toArray()}.
	 */
	@Test
	void testToArray() {
		Object[] array = new Object[list.size()];
		array = list.toArray();
		assertEquals(array[5],list.get(5));
	}

	/**
	 * Test method for {@link utilities.MyArrayList#iterator()}.
	 */
	@Test
	void testIterator() {
		int count = 0;
		Iterator<String> it = list.iterator();
		while(it.hasNext()) {
			assertEquals(it.next(), list.get(count));
			count++;
			}
	}

}
