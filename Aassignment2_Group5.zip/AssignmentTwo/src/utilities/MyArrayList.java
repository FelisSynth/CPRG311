package utilities;

import java.util.NoSuchElementException;

public class MyArrayList<E> implements ListADT<E> {
	private static final long serialVersionUID = -6641976547739553233L;
	
	private E[] array;
	private int size = 0;
	
	@SuppressWarnings("unchecked")
	public MyArrayList() {
		array = (E[]) new Object[10];
	}
	
	

	@Override
	public int size() {
		return size;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void clear() {
		size = 0;
		array = (E[]) new Object[10];
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean add(int index, E toAdd) throws NullPointerException, IndexOutOfBoundsException {
		if(size == array.length) {	
			E[] tempArray = (E[]) new Object[array.length*2];
			for(int count = 0; count < size; count ++) {
				tempArray[count] = array[count];
			}
			array = tempArray;
		}
		E temp = array[index];
		array[index] = toAdd;
		for(int count = index +1; count <= size; count++) {
			toAdd = temp;
			temp = array[count];
			array[count] = toAdd;
		}
		size++;
		return true;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean add(E toAdd) throws NullPointerException {
		if(size == array.length) {	
			E[] tempArray = (E[]) new Object[array.length*2];
			for(int count = 0; count < size; count ++) {
				tempArray[count] = array[count];
			}
			array = tempArray;
		} 
		array[size] = toAdd;
		size++;
		return true;
	}

	@Override
	public boolean addAll(ListADT<? extends E> toAdd) throws NullPointerException {
		Iterator<? extends E> it = toAdd.iterator();
		while(it.hasNext()) {
			add(it.next());
		}
		return true;
		
	}

	@Override
	public E get(int index) throws IndexOutOfBoundsException {
		return array[index];

	}

	@Override
	public E remove(int index) throws IndexOutOfBoundsException {
		E toRemove = array[index];
		for(int count = index ; count < size - 1; count++) {
			array[count] = array[count +1];
		}
		size --;
		return toRemove;
	}

	@Override
	public E remove(E toRemove) throws NullPointerException {
		int index = 0;
		for(int count = 0; count < size(); count++)
		{
			if(array[count].equals(toRemove))
			{
				index = count;
				break;
			}
		}
		remove(index);
		return null;
	}

	@Override
	public E set(int index, E toChange) throws NullPointerException, IndexOutOfBoundsException {
		E toReturn = array[index];
		array[index] = toChange;
		return toReturn;
	}

	@Override
	public boolean isEmpty() {
		return(size == 0);
	}

	@Override
	public boolean contains(E toFind) throws NullPointerException {
		for(int count = 0; count < size(); count++)
		{
			if(array[count].equals(toFind))
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public E[] toArray(E[] toHold) throws NullPointerException {
		for(int count = 0; count<size; count++) {
			toHold[count] = array[count];
		}
		return toHold;
	}

	@Override
	public Object[] toArray() {
		return array;
	}

	@Override
	public Iterator<E> iterator() {
		Iterator<E> it = new Iterator<E>() {
			int currentIndex = 0;
			@Override
			public boolean hasNext() {
				return (currentIndex < size());
			}

			@Override
			public E next() throws NoSuchElementException {
				E elementToReturn = array[currentIndex];
				currentIndex++;
				return elementToReturn;
			}
			
		};
		return it;
	}

}
