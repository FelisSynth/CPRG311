package utilities;

import java.util.EmptyStackException;
import java.util.NoSuchElementException;

public class MyStack<E> implements StackADT<E> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	MyArrayList<E> myArray = new MyArrayList<E>();
	@Override
	public void push(E toAdd) throws NullPointerException {
		myArray.add(toAdd);
	}

	@Override
	public E pop() throws EmptyStackException {
		E temp = myArray.remove(this.size()-1);
		return temp;
	}

	@Override
	public E peek() throws EmptyStackException {
		E temp = myArray.get(this.size()-1);
		return temp;
	}

	@Override
	public void clear() {
		myArray.clear();
		
	}

	@Override
	public boolean isEmpty() {
		return(myArray.isEmpty());
	}

	@Override
	public Object[] toArray() {
		return myArray.toArray();
	}

	@Override
	public E[] toArray(E[] holder) throws NullPointerException {
		return myArray.toArray(holder);
	}

	@Override
	public boolean contains(E toFind) throws NullPointerException {
		return(myArray.contains(toFind));
	}

	@Override
	public int search(E toFind) {
		if (myArray.contains(toFind)) {
			int index = 1;
			Iterator<E> it = iterator();
			while (it.hasNext()){
				if (it.next().equals(toFind)) {
					return index;
				} else {
					index++;
				}
			}
		} 
		return -1;
	}

	@Override
	public Iterator<E> iterator() {
		Iterator<E> it = new Iterator<E>() {
			int currentIndex = 0;
			@Override
			public boolean hasNext() {
				return (currentIndex < size());
			}

			@Override
			public E next() throws NoSuchElementException {
				E elementToReturn = myArray.get(currentIndex);
				currentIndex++;
				return elementToReturn;
			}
			
		};
		return it;
	}

	@Override
	public boolean equals(StackADT<E> that) {
		boolean toReturn = false;
		for(int count = this.size()-1; count >= 0; count--) {
			if((myArray.get(count) != that.pop())) {
				toReturn = false;
			}
			else {
				toReturn = true;
			}
		}
		return toReturn;
	}

	@Override
	public int size() {
		return myArray.size();
	}

}
