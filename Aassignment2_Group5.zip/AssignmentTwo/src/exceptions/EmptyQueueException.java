package exceptions;
public class EmptyQueueException extends Throwable {

}
