package utilities;

public interface QueueADT<E> {
	
	/**
	 * Used to insert an element at the end of the queue
	 * 
	 * @param element - element to be added from the queue
	 */
	public void enqueue(E element);
	
	/**
	 * Used to remove all elements from a queue
	 */
	public void dequeAll();
	
	/**
	 * Used to remove an element from a queue
	 * 
	 * @return the element being removed
	 */
	public Object deque();
	
	/**
	 * Used to retrieve the head of the queue without removing it
	 * 
	 * @return the head value of the queue, if the queue is empty it returns false.
	 */
	public Object peek();

	/**
	 * Used to compare two queues and return a boolean value based on if they are equal
	 * 
	 * @param queue - a queue used to be compared
	 * @return true if both queues are the same, false otherwise.
	 */
	public boolean equals(QueueADT<E> queue);
	
	/**
	 * Used to check if a queue is empty
	 * 
	 * @return true if the queue contains no elements
	 */
	public boolean isEmpty();
	
	/**
	 * Used to check if a queue contains it's maximum amount of elements
	 * 
	 * @return true if the queue contains maximum elements, false otherwise.
	 */
	public boolean isFull();
	
	/**
	 * Used to check the size of the queue.
	 * 
	 * @return the amount of elements in the queue
	 */
	public int size();
	
	/**
	 * Used to copy elements from a queue and put them into a new array
	 * 
	 * @return an array that contains the same elements as the queue
	 */
	public Object toArray();
	
	/**
	 * Used as an alternative for the other toArray method. Only difference being the way it's called.
	 * 
	 * @param queue - the stack to be moved to an array
	 * @return an array with the same elements as the queue.
	 */
	public E[] toArray(E[] queue);
	

	
	
}
