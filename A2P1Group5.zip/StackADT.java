package utilities;

import java.util.Iterator;

public interface StackADT<E> {
	
	/**
	 * Used to push an element to the top of the array
	 */
	public void push(E Element);
	
	/**
	 * Used to clear the array of all its elements
	 */
	public void clear();
	
	/**
	 * Used to remove the top element from the array and gets the value
	 * 
	 * @return last element of the array
	 */
	public Object pop();
	
	/**
	 * Used to retrieve the first element in the stack without removing it
	 * 
	 * @return first object of the stack
	 */
	public Object peek();
	
	/**
	 * Equals is used to compare the equality between two stacks. 
	 * 
	 * @param Object stack used for comparison with another stack
	 * @return true if both stacks are have the same elements in the same order, false otherwise.
	 */
	public boolean equals(StackADT<E> stack);
	
	/**
	 * Used to search a stack for an element
	 * 
	 * @param element to be found in a stack
	 * @return true if the stack being searched has an object equal to the parameter, false otherwise.
	 */
	public boolean contains(E element);
	
	/**
	 * Checks to see if a stack is empty
	 * 
	 * @return true if the stack has no elements, false otherwise.
	 */
	public boolean isEmpty();
	
	/**
	 * Used to search a stack for an element and get its distance from the top of the stack
	 * 
	 * @param element being searched for
	 * @return if the element is found, it returns the position of that element. If the element is not found, returns -1
	 */
	public int search(E element);
	
	/**
	 * Gets the size of the stack
	 * 
	 * @return the amount of elements found in a stack
	 */
	public int size();
	
	/**
	 * Used to iterate over elements in a stack and get their values
	 * 
	 * @return the values of the elements being iterated
	 */
	public Iterator<E> iterator();
	
	/**
	 * Used to copy elements from a stack and put them into a new array
	 * 
	 * @return an array that contains the same elements as the stack
	 */
	public Object[] toArray();
	
	/**
	 * Used as an alternative for the other toArray method. Only difference being the way it's called.
	 * 
	 * @param stack - the stack to be moved to an array
	 * @return an array with the same elements as the stack.
	 */
	public E[] toArray(E[] stack);
	
}
