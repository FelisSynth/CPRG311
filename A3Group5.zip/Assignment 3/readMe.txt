Welcome to our group 5's Word tracker:

1. When the code is utilizing the stored BSTree in a serializable file, you can find it inside the AssignmentThree -> ser -> serial.ser
2. When the code is outputing to console it may not display everything as the console has a max line buffer, to see everything use a file output
3. Exception handling is in place, however if you are trying to cause an error probably not caught, chances are it wont be caught :)
4. The Jar file is Relative to the A1Group5 so if you move the jar it will not find the serial.ser and just create it in the directory
5. Its pretty cool so hope you like
