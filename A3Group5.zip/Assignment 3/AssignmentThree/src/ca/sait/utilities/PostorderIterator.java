package ca.sait.utilities;
import java.util.*;

public class PostorderIterator<E> implements Iterator<E> {
	private Stack<BSTreeNode<E>> stack = new Stack<BSTreeNode<E>>();
	private BSTreeNode<E> currentNode = null;
	
	public PostorderIterator(BSTreeNode<E> node) { 
		this.currentNode = node;
		while(currentNode != null) {
			stack.add(currentNode);
			currentNode = currentNode.getLeftNode();
			}
	}
	
	@Override
    public boolean hasNext() {
        return(!stack.isEmpty());
    }

	@Override
	public E next() throws NoSuchElementException {
        BSTreeNode<E> stackNode = this.stack.pop();
        if (this.hasNext()) {
            if (stackNode == stack.peek().getLeftNode()) {
                currentNode = stack.peek().getRightNode();
                while (currentNode != null) {
                stack.push(currentNode);
                if (currentNode.getLeftNode() != null)
                    currentNode = currentNode.getLeftNode();
                else
                    currentNode = currentNode.getRightNode();
                }        
            }
        }
        return stackNode.getData();
    }

}
