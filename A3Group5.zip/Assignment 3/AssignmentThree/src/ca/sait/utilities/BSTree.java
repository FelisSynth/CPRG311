package ca.sait.utilities;
import ca.sait.exceptions.TreeException;


public class BSTree<E extends Comparable<? super E>> implements BSTreeADT<E> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1417542173658570151L;
	private BSTreeNode<E> root = null;
	private int height;
	private int size;
	@Override
	public BSTreeNode<E> getRoot() throws TreeException {
		return this.root;
	}

	@Override
	public int getHeight() {
		return this.height;
	}

	@Override
	public int size() {
		return this.size;
	}

	@Override
	public boolean isEmpty() {
		return(this.size != 0 && root != null);
	}

	@Override
	public void clear() {
		this.size = 0;
		this.root = null;
	}

	@Override
	public boolean contains(E entry) throws TreeException {
		BSTreeNode<E> currentNode = this.root;
		for(int count = 1; count < this.height; count++) {
			if(currentNode == null) {
				return false;
			} else if(entry.compareTo(currentNode.getData()) == 0) {
				return true;
			} else if(entry.compareTo(currentNode.getData()) > 0) {
				currentNode = currentNode.getRightNode();
			} else if(entry.compareTo(currentNode.getData()) < 0) {
				currentNode = currentNode.getLeftNode();
			}
		}
		return false;
	}

	@Override
	public BSTreeNode<E> search(E entry) throws TreeException {
		BSTreeNode<E> currentNode = this.root;
		for(int count = 1; count <= this.height; count++) {
			if(entry.compareTo(currentNode.getData()) == 0) {
				return currentNode;
			} else if(entry.compareTo(currentNode.getData()) > 0) {
				currentNode = currentNode.getRightNode();
			} else if(entry.compareTo(currentNode.getData()) < 0) {
				currentNode = currentNode.getLeftNode();
			}
		}
		return null;
	}

	@Override
	public boolean add(E newEntry) throws NullPointerException {
		BSTreeNode<E> currentNode = this.root;
		if(this.root == null) {
			this.root = new BSTreeNode<E>(null,null,newEntry);
			size++;
			height++;
			return true;
		} else {
			for(int count = 1; count <= this.height; count++) {
				if(newEntry.compareTo(currentNode.getData()) == 0) {
					if(currentNode.getLeftNode() == null) {
						currentNode.setLeftNode(new BSTreeNode<E>(null,null,newEntry));
						if(count == height) {
							this.height++;
						}
						this.size ++;
						return true;
					} else if(currentNode.getRightNode() == null) {
						currentNode.setRightNode(new BSTreeNode<E>(null,null,newEntry));
						if(count == height - 1) {
							this.height++;
						}
						this.size ++;
						return true;
					} else {
						currentNode = currentNode.getLeftNode();
					}
				} else if(newEntry.compareTo(currentNode.getData()) > 0) {
					if(currentNode.getRightNode() == null) {
						currentNode.setRightNode(new BSTreeNode<E>(null,null,newEntry));
						if(count == height) {
							this.height++;
						}
						this.size ++;
						return true;
					} else {
						currentNode = currentNode.getRightNode();
					}
				} else if(newEntry.compareTo(currentNode.getData()) < 0) {
					if(currentNode.getLeftNode() == null) {
						currentNode.setLeftNode(new BSTreeNode<E>(null,null,newEntry));
						if(count == height) {
							this.height++;
						}
						this.size ++;
						return true;
					} else {
						currentNode = currentNode.getLeftNode();
					}
				}
			}
		}
		return false;
	}

	@Override
	public Iterator<E> inorderIterator() {
		InorderIterator<E> it = new InorderIterator<E>(this.root);
		return it;
	}

	@Override
	public Iterator<E> preorderIterator() {
		PreorderIterator<E> it = new PreorderIterator<E>(this.root);
		return it;
	}

	@Override
	public Iterator<E> postorderIterator() {
		PostorderIterator<E> it = new PostorderIterator<E>(this.root);
		return it;
	}
}