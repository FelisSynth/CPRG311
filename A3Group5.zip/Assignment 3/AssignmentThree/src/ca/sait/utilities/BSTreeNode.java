package ca.sait.utilities;
import java.io.*;

public class BSTreeNode<E> implements Serializable{
	
	private static final long serialVersionUID = -5906054447715249463L;
	private BSTreeNode<E> leftNode = null;;
	private BSTreeNode<E> rightNode = null;
	private E data = null;
	
	public BSTreeNode(BSTreeNode<E> leftNode, BSTreeNode<E> rightNode, E data) {
		this.leftNode = leftNode;
		this.rightNode = rightNode;
		this.data = data;
	}

	public BSTreeNode<E> getLeftNode() {
		return leftNode;
	}

	public void setLeftNode(BSTreeNode<E> leftNode) {
		this.leftNode = leftNode;
	}

	public BSTreeNode<E> getRightNode() {
		return rightNode;
	}

	public void setRightNode(BSTreeNode<E> rightNode) {
		this.rightNode = rightNode;
	}

	public E getData() {
		return data;
	}

	public void setData(E data) {
		this.data = data;
	}
	
	
	
}
