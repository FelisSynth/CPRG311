package ca.sait.utilities;
import java.util.NoSuchElementException;
import java.util.Stack;
/* Ideas to recursively iterating to accomplish goal was found on 
 * Code written by Dylano
 * https://www.java67.com/2016/08/binary-tree-inorder-traversal-in-java.html
 * Author: Javin Paul
 */


public class InorderIterator<E> implements Iterator<E> {
	private Stack<BSTreeNode<E>> stack = new Stack<BSTreeNode<E>>();

	public InorderIterator(BSTreeNode<E> node) {
		this.inOrder(node);
	}

	private void inOrder(BSTreeNode<E> node) {
		if(node == null) {
			return;
		} else {
			inOrder(node.getRightNode());
			stack.add(node);
			inOrder(node.getLeftNode());
		}
	}
	
	@Override
	public boolean hasNext() {
        return(!stack.isEmpty());
    }
	
	@Override
	public E next() throws NoSuchElementException {
        E data = stack.pop().getData();
        return data;
    }
}
