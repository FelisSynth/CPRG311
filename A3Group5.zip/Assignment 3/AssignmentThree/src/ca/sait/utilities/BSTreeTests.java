package ca.sait.utilities;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ca.sait.exceptions.TreeException;

class BSTreeTests {

	private BSTree<Integer> tree;
	
	@BeforeEach
	void setUp() {
		tree  = new BSTree<Integer>();
		tree.add(4);
		tree.add(3);
		tree.add(2);
		tree.add(1);
		tree.add(5);
		tree.add(6);

	}
	
	@AfterEach
	void end() {
		tree.clear();
	}
	
	@Test
	void testHeight() {
		assertEquals(4, tree.getHeight());
	}
	
	@Test
	void testSize() {
		assertEquals(6, tree.size());
	}
	
	@Test
	void testEmpty() {
		assertTrue(tree.isEmpty());
	}
	
	@Test 
	void testAdd() throws TreeException {
		assertTrue(tree.add(7));
		assertEquals(7, tree.size());
	}
	
	@Test
	void testPreorderIterator() {
		Iterator<Integer> it = tree.preorderIterator();
			assertEquals(4, it.next());
			assertEquals(3, it.next());
			assertEquals(2, it.next());
			assertEquals(1, it.next());
			assertEquals(5, it.next());
			assertEquals(6, it.next());
		}
	
	@Test
	void testPostorderIterator() {
		Iterator<Integer> it = tree.postorderIterator();
			assertEquals(1, it.next());
			assertEquals(2, it.next());
			assertEquals(3, it.next());
			assertEquals(6, it.next());
			assertEquals(5, it.next());
			assertEquals(4, it.next());
	}
	
	@Test
	void testInorderIterator() {
		Iterator<Integer> it = tree.inorderIterator();
			assertEquals(1, it.next());
			assertEquals(2, it.next());
			assertEquals(3, it.next());
			assertEquals(4, it.next());
			assertEquals(5, it.next());
			assertEquals(6, it.next());
	}
	
	@Test
	void testContains() throws TreeException {
		assertTrue(tree.contains(3));
		assertFalse(tree.contains(10));
	}
	
	@Test
	void testSearch() throws TreeException {
		BSTreeNode<Integer> searchedNode = tree.search(1);
		assertEquals(searchedNode.getData(), 1);
	}
}
