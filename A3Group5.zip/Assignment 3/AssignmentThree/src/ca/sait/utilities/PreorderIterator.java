package ca.sait.utilities;

import java.util.NoSuchElementException;
import java.util.Stack;

public class PreorderIterator<E> implements Iterator<E>{
	private Stack<BSTreeNode<E>> stack = new Stack<BSTreeNode<E>>();
	private BSTreeNode<E> currentNode = null;
	
	public PreorderIterator(BSTreeNode<E> node) {
		this.currentNode = node;
		stack.add(currentNode);
	}

	@Override
	public boolean hasNext() {
		return(!stack.isEmpty());
	}

	@Override
	public E next() throws NoSuchElementException {
		while (!stack.isEmpty()) {
            BSTreeNode<E> node = stack.pop();    
            if (node.getRightNode() != null) stack.push(node.getRightNode());
            
            if (node.getLeftNode() != null) stack.push(node.getLeftNode());
            return node.getData();
        }
	return null;
	}
}
