package ca.sait.models;
import java.io.Serializable;
import java.util.*;
class FileLine implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3437228560128122455L;
	private String fileName = null;
	private LinkedList<Integer> lines = new LinkedList<Integer>();
	
	public FileLine(String fileName) {
		this.fileName = fileName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public LinkedList<Integer> getLines() {
		return lines;
	}

	public void addLine(int toAdd) {
		if(!lines.contains(toAdd)) {
			this.lines.add(toAdd);
		}
	}

	@Override
	public String toString() {
		Iterator<Integer> it = lines.iterator();
		String toReturn = (fileName + "'s Line Numbers: \n");
		int lineCount = 0;
		
		while(it.hasNext()) {
			lineCount ++;
			toReturn += "|" + it.next() + "| ";
			if(lineCount % 10 == 0) {
				toReturn += "\n";
			}
		}
		
		return toReturn;
	}
	
	
}
