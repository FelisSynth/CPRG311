package ca.sait.models;
import java.io.Serializable;
import java.util.*;

public class Word implements Comparable<Word>, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2001836004536272899L;
	private String word = null;
	private LinkedList<FileLine> fileLines = new LinkedList<FileLine>();
	private int occurance = 0;
	
	public Word(String word, String fileName, int lineNumber) {
		this.word = word;
		this.addLine(fileName, lineNumber);
	}

	@Override
	public int compareTo(Word toCompare) {
		return(this.word.compareTo(toCompare.word));
	}
	
	public void addLine(String fileName, int lineNumber) {
		Iterator<FileLine> fileLineIterator = fileLines.iterator();
		FileLine temp = null;
		while(fileLineIterator.hasNext()) {
			temp = fileLineIterator.next();
			if(temp.getFileName().equals(fileName)) {
				temp.addLine(lineNumber);
				occurance ++;
				return;
			}
		}
		fileLines.add(new FileLine(fileName));
		addLine(fileName, lineNumber);
	}

	public String printPF() {
		String toReturn = "\n\n" + this.word.toUpperCase() + ":";
		Iterator<FileLine> it = this.fileLines.iterator();
		while(it.hasNext()) {
			toReturn += "\n" + it.next().getFileName();
		}
		return toReturn;
	}
	
	public String printPL() {
		String toReturn = "\n\n" + this.word.toUpperCase() + ":\n";
		Iterator<FileLine> it = this.fileLines.iterator();
		while(it.hasNext()) {
			toReturn += it.next().toString();
		}
		return toReturn;
	}
	
	public String printPO() {
		String toReturn = "\n\n" + this.word.toUpperCase() + ":\nWord Occurance: " + this.occurance + "\n";
		Iterator<FileLine> it = this.fileLines.iterator();
		while(it.hasNext()) {
			toReturn += it.next().toString();
		}
		return toReturn;
	}
}
