package ca.sait.drivers;
import java.io.*;
import java.util.*;
import ca.sait.utilities.BSTree;
import ca.sait.utilities.Iterator;
import ca.sait.exceptions.TreeException;
import ca.sait.models.Word;
public class Driver {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws NullPointerException, TreeException, IOException, ClassNotFoundException {
		FileWriter fileWriter = null;
		String inputFilePath = "";
		String outputMethod = "";
		String outputFilePath = "";
		inputFilePath += args[0];
		outputMethod += args[1].toLowerCase();
		
		for(String input : args) {
			if(args.length > 2 && input.toLowerCase().startsWith("-f")) {
				outputFilePath = args[2].substring(2);
			}
		}
		
		Scanner scan = new Scanner(new File(inputFilePath));
		BSTree<Word> tree = null;
		try {
			FileInputStream fileInputStream = new FileInputStream(new File("AssignmentThree/ser/serial.ser"));
			ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
			tree = (BSTree<Word>) objectInputStream.readObject();
		} catch(EOFException e) {
			tree = new BSTree<Word>();
			System.out.println("The file contained no Data - Adding current tree to File: AssignmentThree/ser/serial.ser...");
		} catch(IOException e) {
			System.out.print("An error occured while loading the Tree, tree will NOT be saved\n");
			tree = new BSTree<Word>();
		}
			
		int lineNumber = 1;
		while(scan.hasNextLine())
		{
			
			String line[] = scan.nextLine().split("\\W+");
			for(int x = 0; x < line.length; x++) {
				Word temp = new Word(line[x].toLowerCase(), inputFilePath, lineNumber);
				if(tree.contains(temp)) {
					tree.search(temp).getData().addLine(inputFilePath, lineNumber);
					
				} else {
					tree.add(temp);
				}
			}
			lineNumber++;
		}
		scan.close();
		
		try {
			FileOutputStream fileOutputStream = new FileOutputStream(new File("AssignmentThree/ser/serial.ser"));
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(tree);
		} catch(IOException e) {
			System.out.println("An error occured while saving the Tree, tree will NOT be saved\n");
		}
		
		try {
			fileWriter = new FileWriter(new File(outputFilePath));
		} catch(IOException e) {
			System.out.println("No output file found, printing results to console...");
			outputFilePath = "";
		}
		
		
		Iterator<Word> it = tree.inorderIterator();
		
		switch(outputMethod) {
		case "-pl":
			if(outputFilePath.length() > 0) {
				while(it.hasNext()) {
					Word temp = it.next();
					fileWriter.write(temp.printPL());
				}
			} else {
				while(it.hasNext()) {
					Word temp = it.next();
					System.out.println(temp.printPL());
				}
			}
			break;
			
		case "-pf": 
			if(outputFilePath.length() > 0) {
				while(it.hasNext()) {
					Word temp = it.next();
					fileWriter.write(temp.printPF());
				}
			} else {
				while(it.hasNext()) {
					Word temp = it.next();
					System.out.println(temp.printPF());
				}
			}
			break;
		
		case "-po":
			if(outputFilePath.length() > 0) {
				while(it.hasNext()) {
					Word temp = it.next();
					fileWriter.write(temp.printPO());
				}
			} else {
				while(it.hasNext()) {
					Word temp = it.next();
					System.out.println(temp.printPO());
				}
			}
			break;
		default:
			System.out.println("Invalid format option try again using either \"-pl,-po,-pf ");
		}
	}
}
