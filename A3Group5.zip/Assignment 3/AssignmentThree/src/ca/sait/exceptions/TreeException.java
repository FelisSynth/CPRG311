package ca.sait.exceptions;

public class TreeException extends Throwable{

	private static final long serialVersionUID = -2647077068989782122L;

}
